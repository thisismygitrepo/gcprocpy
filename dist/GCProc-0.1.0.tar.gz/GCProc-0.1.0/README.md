
# GCPROCPY

This is a Python implementation based on `https://github.com/AskExplain/gcproc/blob/1_prepare`


To be done:
* Using a zero-shot NN to provide good intialization.
* Extend the technique to multi-linear agebra. This is of interest in biological structures data where there is metadata that can be used.
* generalized assigment problem.
* Impuation learning
* Kernelized version.


